#!/usr/bin/env python
# coding: utf-8

# In[14]:


import pandas as pd

df = pd.read_excel("ucdpold.xlsx")
df_filtered = df[df["type_of_conflict"].isin([3, 4])]
years = list(range(1990, 2021))
df_new = pd.DataFrame(columns=["Country Name"] + years)
df_new["Country Name"] = df_filtered["location_inc"].unique()
for year in years:
    year_values = df_filtered[df_filtered["year"] == year].groupby("location_inc")["bd_best"].sum()
    df_new[year] = year_values.reindex(df_new["Country Name"]).values

df_new.to_excel("ucdpnew.xlsx", index=False)

