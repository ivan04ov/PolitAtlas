#!/usr/bin/env python
# coding: utf-8

# In[7]:


import pandas as pd

input_file = pd.read_excel('ethnicsold.xlsx')
data = input_file[['statename', 'group', 'from', 'to', 'size']]
grouped_data = data.groupby(['statename', 'group', 'from', 'to']).max()['size'].reset_index()
new_data = pd.DataFrame(columns=['Country'] + list(range(1990, 2021)))


for i, row in grouped_data.iterrows():
    country = row['statename']
    start_year = row['from']
    end_year = row['to']
    value = row['size']
    if country in new_data['Country'].values:
        for year in range(1990, 2021):
            if start_year <= year <= end_year:
                current_value = new_data.loc[new_data['Country'] == country, year].values[0]
                new_value = value if value > current_value else current_value
                new_data.loc[new_data['Country'] == country, year] = new_value
    else:
        new_row = pd.DataFrame(data=[[country] + [value if start_year <= year <= end_year else 0 for year in range(1990, 2021)]],
                               columns=['Country'] + list(range(1990, 2021)))
        new_data = new_data.append(new_row)

new_data = new_data.sort_values('Country')
new_data.to_excel('ethnicsnew4.xlsx', index=False)


# In[ ]:




